public int calculateResult(Exam exam){
int totalCorrect=0;
Map<Integer,Integer>
userSelectionsMap=exam.selections;
List userSelectionsList=new ArrayList(10);
for (Map.Entry<Integer, Integer> entry
:userSelectionsMap.entrySet()) {
userSelectionsList.add(entry.getValue());
}
List questionList=exam.questionList;
List correctAnswersList=new ArrayList(10);
for(QuizQuestion question: questionList){
correctAnswersList.add(question.getCorrectOptionIndex());
}
for(int i=0;i<selections.size();i++){
System.out.println(userSelectionsList.get(i)+"
--- "+correctAnswersList.get(i));
if((userSelectionsList.get(i)-
1)==correctAnswersList.get(i)){
totalCorrect++;
}
}
System.out.println("You Got "+totalCorrect+"
Correct");
return totalCorrect;
}
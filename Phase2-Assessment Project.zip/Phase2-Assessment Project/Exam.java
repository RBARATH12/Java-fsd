public class Exam {
Document dom;
public int currentQuestion=0;
public Map selections=new LinkedHashMap();
public ArrayList questionList = new ArrayList(10);
public Exam(String test) throws
SAXException,ParserConfigurationException,IOException,
URISyntaxException{
dom=CreateDOM.getDOM(test);
}
 // code
}

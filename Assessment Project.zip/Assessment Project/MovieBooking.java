package assessment;

import java.util.Arrays;

import java.util.Scanner;



class Movie {

    private String title;

    private String showtime;



    public Movie(String title, String showtime) {

        this.title = title;

        this.showtime = showtime;

    }



    public String getTitle() {

        return title;

    }



    public String getShowtime() {

        return showtime;

    }

}



class Seat {

    private String seatNumber;

    private boolean isBooked;



    public Seat(String seatNumber) {

        this.seatNumber = seatNumber;

        this.isBooked = false;

    }



    public String getSeatNumber() {

        return seatNumber;

    }



    public boolean isBooked() {

        return isBooked;

    }



    public void book() {

        isBooked = true;

    }

}



class Theatre {

    private Movie movie;

    private Seat[] seats;



    public Theatre(Movie movie, int numSeats) {

        this.movie = movie;

        this.seats = new Seat[numSeats];

        initializeSeats();

    }



    private void initializeSeats() {

        for (int i = 0; i < seats.length; i++) {

            seats[i] = new Seat(String.format("%02d", i + 1));

        }

    }



    public Movie getMovie() {

        return movie;

    }



    public Seat[] getSeats() {

        return seats;

    }



    public boolean bookSeat(int seatIndex) {

        if (seatIndex >= 0 && seatIndex < seats.length && !seats[seatIndex].isBooked()) {

            seats[seatIndex].book();

            return true;

        }

        return false;

    }



    public boolean bookSeats(int startIndex, int endIndex) {

        if (startIndex < 0 || endIndex >= seats.length || startIndex >= endIndex) {

            return false;

        }



        for (int i = startIndex; i <= endIndex; i++) {

            if (seats[i].isBooked()) {

                return false;

            }

        }



        for (int i = startIndex; i <= endIndex; i++) {

            seats[i].book();

        }



        return true;

    }

}



class FrontDesk {

    private static final String USERNAME = "admin";

    private static final String PASSWORD = "password";

    private String currentPassword;

    private Theatre theatre;



    public FrontDesk(Theatre theatre) {

        this.theatre = theatre;

        this.currentPassword = PASSWORD;

    }



    public boolean login(String username, String password) {

        return USERNAME.equals(username) && currentPassword.equals(password);

    }



    public void updatePassword(String newPassword) {

        currentPassword = newPassword;

    }



    public void viewSeating() {

        Movie movie = theatre.getMovie();

        Seat[] seats = theatre.getSeats();



        System.out.println("Movie: " + movie.getTitle() + " (" + movie.getShowtime() + ")");

        System.out.println("Seating Arrangement:");



        for (int i = 0; i < seats.length; i++) {

            Seat seat = seats[i];

            System.out.print(seat.getSeatNumber() + " " + (seat.isBooked() ? "[X]" : "[ ]") + " ");



            if ((i + 1) % 10 == 0) {

                System.out.println();

            }

        }

    }



    public void bookTicket() {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter seat number(s) (e.g., 1, 2-5): ");

        String seatSelection = scanner.nextLine();



        if (seatSelection.contains("-")) {

            String[] range = seatSelection.split("-");

            int startIndex = Integer.parseInt(range[0]) - 1;

            int endIndex = Integer.parseInt(range[1]) - 1;



            if (theatre.bookSeats(startIndex, endIndex)) {

                System.out.println("Seats booked successfully!");

            } else {

                System.out.println("Invalid seat selection or seats already booked.");

            }

        } else {

            int seatIndex = Integer.parseInt(seatSelection) - 1;



            if (theatre.bookSeat(seatIndex)) {

                System.out.println("Seat booked successfully!");

            } else {

                System.out.println("Invalid seat number or seat already booked.");

            }

        }

    }



    public void checkStatus() {

        viewSeating();

    }

}



public class MovieBooking {

    public static void main(String[] args) {

        Movie movie = new Movie("The Avengers", "7:00 PM");

        Theatre theatre = new Theatre(movie, 100);

        FrontDesk frontDesk = new FrontDesk(theatre);



        Scanner scanner = new Scanner(System.in);

        boolean isLoggedIn = false;



        while (true) {

            System.out.println("\nTheatre Booking System");

            System.out.println("1. Login");

            System.out.println("2. Update Password");

            System.out.println("3. View Seating");

            System.out.println("4. Book Ticket");

            System.out.println("5. Check Status");

            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");



            int choice = scanner.nextInt();

            scanner.nextLine(); // Consume newline character



            switch (choice) {

                case 1:

                    System.out.print("Enter username: ");

                    String username = scanner.nextLine();

                    System.out.print("Enter password: ");

                    String password = scanner.nextLine();



                    if (frontDesk.login(username, password)) {

                        isLoggedIn = true;

                        System.out.println("Login successful!");

                    } else {

                        System.out.println("Invalid username or password.");

                    }

                    break;

                case 2:

                    if (isLoggedIn) {

                        System.out.print("Enter new password: ");

                        String newPassword = scanner.nextLine();

                        frontDesk.updatePassword(newPassword);

                        System.out.println("Password updated successfully!");

                    } else {

                        System.out.println("Please login first.");

                    }

                    break;

                case 3:

                    frontDesk.viewSeating();

                    break;

                case 4:

                    if (isLoggedIn) {

                        frontDesk.bookTicket();

                    } else {

                        System.out.println("Please login first.");

                    }

                    break;

                case 5:

                    frontDesk.checkStatus();

                    break;

                case 6:

                    System.out.println("Exiting...");

                    System.exit(0);

                default:

                    System.out.println("Invalid choice. Please try again.");

            }

        }

    }

}



package practiceproject3;

public class Program01 {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9}; 
        int steps = 5; 

        System.out.println("Original Array:");
        printArray(arr);

        rightRotate(arr, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps:");
        printArray(arr);
    }

   
    public static void rightRotate(int[] arr, int steps) {
        int n = arr.length;
        steps = steps % n;

        reverse(arr, 0, n - 1);
        reverse(arr, 0, steps - 1); 
        reverse(arr, steps, n - 1);
    }

   
    public static void reverse(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }

   
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

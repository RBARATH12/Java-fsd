package practiceproject3;

import java.util.Arrays;

public class Program02 {
    public static void main(String[] args) {
        int[] arr = {10, 2, 8, 6, 3, 7, 1, 5, 9, 4}; 
        int k = 4;

        int fourthSmallest = findKthSmallest(arr, k);
        
        System.out.println("The " + k + "th smallest element is: " + fourthSmallest);
    }

    public static int findKthSmallest(int[] arr, int k) {
        Arrays.sort(arr); 

        
        return arr[k - 1];
    }
}

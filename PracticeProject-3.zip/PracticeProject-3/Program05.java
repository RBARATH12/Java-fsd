package practiceproject3;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class Program05 {
    Node head;

    public void deleteNode(int key) {
        Node temp = head;
        Node prev = null;

       
        if (temp != null && temp.data == key) {
            head = temp.next;
            return;
        }

        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

       
        if (temp == null) return;

        prev.next = temp.next;
    }

    public void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Program05 list = new Program05();
        list.head = new Node(1);
        list.head.next = new Node(2);
        list.head.next.next = new Node(3);
        list.head.next.next.next = new Node(4);
        list.head.next.next.next.next = new Node(5);

        System.out.println("Original List:");
        list.printList();

        int keyToDelete = 3;
        list.deleteNode(keyToDelete);

        System.out.println("List after deleting first occurrence of " + keyToDelete + ":");
        list.printList();
    }
}
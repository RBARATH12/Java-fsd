package PracticeProject2;

class MyThread1 extends Thread {
    public void run() {
        System.out.println("Thread created by extending Thread class");
    }
}


class MyThread2 implements Runnable {
    public void run() {
        System.out.println("Thread created by implementing Runnable interface");
    }
}

public class Program01 {
    public static void main(String[] args) {
        
        MyThread1 thread1 = new MyThread1();
        
        
        MyThread2 thread2 = new MyThread2();
        Thread t = new Thread(thread2);
        
        
        thread1.start();
        t.start();
    }
}
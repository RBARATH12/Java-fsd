package PracticeProject2;

class Person {
    private String name;
    private int age;

    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}


class Student extends Person {
    private int studentId;

    
    public Student(String name, int age, int studentId) {
        super(name, age);
        this.studentId = studentId;
    }

  
    public void displayInfo() {
        System.out.println("Name: " + getName());
        System.out.println("Age: " + getAge());
        System.out.println("Student ID: " + studentId);
    }
}

class Shape {
    public void draw() {
        System.out.println("Drawing a shape");
    }
}

class Circle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a circle");
    }
}


abstract class Animal {
    public abstract void makeSound();
}

class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Dog barks");
    }
}

public class Program08 {
    public static void main(String[] args) {
        
        Person person = new Person("John", 30);
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
        System.out.println();

      
        Student student = new Student("Alice", 20, 1234);
        student.displayInfo();
        System.out.println();

        
        Shape shape = new Circle();
        shape.draw();
        System.out.println();

        
        Animal dog = new Dog();
        dog.makeSound();
    }
}
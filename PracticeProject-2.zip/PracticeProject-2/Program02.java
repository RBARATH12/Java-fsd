package PracticeProject2;

class SleepThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("SleepThread: " + i);
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

class WaitThread extends Thread {
    private Object lock;

    public WaitThread(Object lock) {
        this.lock = lock;
    }

    public void run() {
        synchronized (lock) {
            System.out.println("WaitThread waiting...");
            try {
                lock.wait(); 
            } catch (InterruptedException e) {
                System.out.println(e);
            }
            System.out.println("WaitThread notified");
        }
    }
}

public class Program02 {
    public static void main(String[] args) {
        Object lock = new Object();

        SleepThread sleepThread = new SleepThread();
        WaitThread waitThread = new WaitThread(lock);

        sleepThread.start();
        waitThread.start();

        try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            System.out.println(e);
        }

        synchronized (lock) {
            System.out.println("Main thread notifying...");
            lock.notify(); 
        }
    }
}
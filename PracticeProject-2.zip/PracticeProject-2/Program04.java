package PracticeProject2;

import java.util.Scanner;

public class Program04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter two numbers: ");

        try {
            int num1 = scanner.nextInt();
            int num2 = scanner.nextInt();

            int result = divide(num1, num2);
            System.out.println("Result of division: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
            System.out.println("Scanner closed.");
        }
    }

    public static int divide(int a, int b) {
        return a / b;
    }
}

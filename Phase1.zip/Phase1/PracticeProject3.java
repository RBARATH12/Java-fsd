package phase01;

public class PracticeProject3 {

    
    public void greet() {
        System.out.println("Hello! Welcome to the MethodExample class.");
    }

    
    public int add(int a, int b) {
        return a + b;
    }

    
    public void printSum(int x, int y) {
        int sum = x + y;
        System.out.println("Sum of " + x + " and " + y + " is: " + sum);
    }

    
    public static void staticMethod() {
        System.out.println("This is a static method.");
    }

    public static void main(String[] args) {
    	PracticeProject3 example = new PracticeProject3();

        
        System.out.println("Calling methods using object reference:");
        example.greet(); 
        int result = example.add(5, 7);
        System.out.println("Result of addition: " + result);
        example.printSum(10, 20); 

        
        System.out.println("\nCalling static method directly:");
        staticMethod();

        
        System.out.println("\nCalling static method using class name:");
        PracticeProject3.staticMethod();
    }
}
package phase01;

public class PracticeProject1 {
    public static void main(String[] args) {
        
        int intValue = 10;
        double doubleValue = intValue; 
        System.out.println("Implicit Type Casting:");
        System.out.println("int value: " + intValue);
        System.out.println("double value: " + doubleValue);
        
        
        double doubleVal = 20.56;
        int intVal = (int) doubleVal; 
        System.out.println("\nExplicit Type Casting:");
        System.out.println("double value: " + doubleVal);
        System.out.println("int value: " + intVal);
    }
}

package phase01;

public class PracticeProject4 {
    private int value;

   
    public PracticeProject4() {
        System.out.println("Default constructor called.");
        value = 0;
    }

    
    public PracticeProject4(int value) {
        System.out.println("Parameterized constructor called.");
        this.value = value;
    }

    
    public PracticeProject4(PracticeProject4 other) {
        System.out.println("Copy constructor called.");
        this.value = other.value;
    }

    
    private PracticeProject4(String message) {
        System.out.println("Private constructor called with message: " + message);
    }

    public void displayValue() {
        System.out.println("Value: " + value);
    }

    public static void main(String[] args) {
        
    	PracticeProject4 example1 = new PracticeProject4();
        example1.displayValue();

        
        PracticeProject4 example2 = new PracticeProject4(42);
        example2.displayValue();

        
        PracticeProject4 example3 = new PracticeProject4(example2);
        example3.displayValue();

        
    }
}
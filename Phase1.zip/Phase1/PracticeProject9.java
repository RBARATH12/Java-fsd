package phase01;

public class PracticeProject9 {
    public static void main(String[] args) {
        
        int[] intArray = {1, 2, 3, 4, 5};
        
        
        System.out.println("Integer Array:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.println("Element at index " + i + ": " + intArray[i]);
        }

        
        String[] stringArray = {"apple", "banana", "orange", "grape", "melon"};
        
       
        System.out.println("\nString Array:");
        for (int i = 0; i < stringArray.length; i++) {
            System.out.println("Element at index " + i + ": " + stringArray[i]);
        }

        
        intArray[2] = 10;
        System.out.println("\nUpdated Integer Array:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.println("Element at index " + i + ": " + intArray[i]);
        }
    }
}
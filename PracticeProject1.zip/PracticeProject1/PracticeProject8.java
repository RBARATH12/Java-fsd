package phase01;

public class PracticeProject8 {
    public static void main(String[] args) {
        
        String originalString = "Hello, world!";
        System.out.println("Original String: " + originalString);

        
        StringBuffer stringBuffer = new StringBuffer(originalString);
        System.out.println("String converted to StringBuffer: " + stringBuffer);

        
        StringBuilder stringBuilder = new StringBuilder(originalString);
        System.out.println("String converted to StringBuilder: " + stringBuilder);
    }
}